import{f as r,b as i}from"../chunks/Dt4-8ENk.js";import"../chunks/DcbHPUAs.js";import{Z as n,$ as a}from"../chunks/CEupPios.js";import{h as s}from"../chunks/FRmCoyac.js";import{M as l}from"../chunks/BZMb1Vrw.js";var p=r(`<div><h1>Imprint</h1> <h2>Information according to § 5 TMG (German Telemedia Act)</h2> <p>Rabbit Development<br/> Karlstr. 120<br/> 76137 Karlsruhe, Germany</p> <p><strong>Represented by:</strong><br/> Robin Danzinger, Martin Farkas</p> <h3>Contact</h3> <p>E-mail: <a href="mailto:hello@gardenjs.org">hello@gardenjs.org</a></p> <h3>EU dispute resolution</h3> <p>The European Commission provides a platform for online dispute resolution
      (OS): <a href="https://ec.europa.eu/consumers/odr/main/index.cfm?event=main.home.chooseLanguage" target="_blank" rel="noopener noreferrer">https://ec.europa.eu/consumers/odr/</a>. You can find our e-mail address in the legal notice above.</p> <h3>Consumer dispute resolution / universal arbitration board</h3> <p>We are not willing or obliged to participate in dispute resolution
      proceedings before a consumer arbitration board.</p> <h2>Disclaimer</h2> <h3>Liability for content</h3> <p>As a service provider, we are responsible for our own content on these
      pages in accordance with Section 7 (1) TMG (German Telemedia Act) and
      general legislation. According to §§ 8 to 10 TMG, however, we as a service
      provider are not obliged to monitor transmitted or stored third-party
      information or to investigate circumstances that indicate illegal
      activity.</p> <p>Obligations to remove or block the use of information in accordance with
      general legislation remain unaffected by this. However, liability in this
      respect is only possible from the time of knowledge of a specific
      infringement. As soon as we become aware of such infringements, we will
      remove this content immediately.</p> <h3>Liability for links</h3> <p>Our website contains links to external third-party websites over whose
      content we have no influence. Therefore, we cannot accept any liability
      for this third-party content. The respective provider or operator of the
      pages is always responsible for the content of the linked pages. The
      linked pages were checked for possible legal violations at the time of
      linking. Illegal content was not recognizable at the time of linking.</p> <p>However, permanent monitoring of the content of the linked pages is not
      reasonable without concrete evidence of an infringement. If we become
      aware of any legal infringements, we will remove such links immediately.</p> <h3>Copyright</h3> <p>The content and works created by the site operators on these pages are
      subject to German copyright law. Duplication, processing, distribution and
      any kind of exploitation outside the limits of copyright law require the
      written consent of the respective author or creator. Downloads and copies
      of this site are only permitted for private, non-commercial use.</p> <p>Insofar as the content on this site was not created by the operator, the
      copyrights of third parties are respected. In particular, third-party
      content is identified as such. Should you nevertheless become aware of a
      copyright infringement, please inform us accordingly. If we become aware
      of any infringements, we will remove such content immediately.</p> <p>&nbsp;</p> <p>Source: <a href="https://www.e-recht24.de" target="_blank" rel="noreferrer">eRecht24</a>. Translation: <a href="https://www.deepl.com/" target="_blank">DeepL</a>.</p></div>`);function u(o){s("1d6p8ks",e=>{n(()=>{a.title="Legal Notice :: Gardenjs UI Component Explorer"})}),l(o,{children:(e,c)=>{var t=p();i(e,t)},$$slots:{default:!0}})}export{u as component};
