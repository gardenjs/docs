import{f as a,b as r}from"../chunks/Dt4-8ENk.js";import"../chunks/DcbHPUAs.js";import{Z as i,$ as s}from"../chunks/CEupPios.js";import{h as n}from"../chunks/FRmCoyac.js";import{M as h}from"../chunks/BZMb1Vrw.js";var l=a(`<div><h1>Data protection</h1> <h2>1. Data protection at a glance</h2> <h3>General information</h3> <p>The following information provides a simple overview of what happens to
      your personal data when you visit this website. Personal data is any data
      that can be used to identify you personally. Detailed information on the
      subject of data protection can be found in our data protection declaration
      listed below this text.</p> <h3>Data collection on this website:</h3> <h4>Who is responsible for data collection on this website?</h4> <p>Data processing on this website is carried out by the website operator.
      You can find the operator's contact details in the “Information on the
      controller” section of this privacy policy.</p> <h4>How do we collect your data?</h4> <p>On the one hand, your data is collected when you provide it to us. This
      may, for example, be data that you enter in a contact form.</p> <p>Other data is collected automatically or with your consent by our IT
      systems when you visit the website. This is primarily technical data (e.g.
      internet browser, operating system or time of page view). This data is
      collected automatically as soon as you enter this website.</p> <h4>What do we use your data for?</h4> <p>Some of the data is collected to ensure that the website is provided
      without errors. Other data can be used to analyze your user behavior.</p> <h4>What rights do you have with regard to your data?</h4> <p>You have the right to receive information about the origin, recipient and
      purpose of your stored personal data free of charge at any time. You also
      have the right to request the correction or deletion of this data. If you
      have given your consent to data processing, you can revoke this consent at
      any time for the future. You also have the right to request the
      restriction of the processing of your personal data under certain
      circumstances. You also have the right to lodge a complaint with the
      competent supervisory authority.<br/>You can contact us at any time if
      you have any further questions on the subject of data protection.</p> <h2>2. Hosting</h2> <p>Our host collects the following data that your browser transmits in log
      files:</p> <p>IP address, the address of the previously visited website (referrer
      request header), date and time of the request, time zone difference to
      Greenwich Mean Time, content of the request, HTTP status code, amount of
      data transferred, website from which the request originates and
      information about the browser and operating system.</p> <p>This is necessary to display our website and to ensure stability and
      security. This corresponds to our legitimate interest within the meaning
      of Art. 6 para. 1 sentence 1 lit. f GDPR.</p> <p>There is no tracking and we have no direct access to this data.</p> <p>We use the following hoster for the provision of our website:</p> <p>GitHub Inc.<br/>88 Colin P Kelly Jr St<br/>San Francisco, CA 94107<br/>United States</p> <p>This is the recipient of your personal data. This corresponds to our
      legitimate interest within the meaning of Art. 6 para. 1 sentence 1 lit. f
      GDPR in not having to maintain a server on our premises ourselves. Server
      location is USA.</p> <p>Further information on objection and removal options vis-à-vis GitHub can
      be found at: <a href="https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement" target="_blank">https://docs.github.com/en/site-policy/privacy-policies/github-general-privacy-statement</a></p> <p>You have the right to object to the processing. Whether the objection is
      successful must be determined as part of a balancing of interests.</p> <p>The data will be deleted as soon as the purpose of the processing no
      longer applies.</p> <p>The processing of the data specified in this section is not required by
      law or contract. The functionality of the website is not guaranteed
      without the processing.</p> <p>GitHub has implemented compliance measures for international data
      transfers. These apply to all global activities where GitHub processes
      personal data of natural persons in the EU. These measures are based on
      the EU Standard Contractual Clauses (SCCs). Further information can be
      found at: <a href="https://docs.github.com/en/site-policy/privacy-policies" target="_blank">https://docs.github.com/en/site-policy/privacy-policies</a></p> <h3>Order processing/legal information</h3> <p>In principle, an order processing contract must be concluded with the
      hoster. The Bavarian State Office for Data Protection Supervision has made
      an exception for the hosting of purely static websites. In the event that
      the website is used for self-presentation, e.g. by associations or small
      companies, no personal data flows to the operator and no tracking takes
      place, there is no order processing. It goes on to say: "The fact that IP
      addresses, i.e. personal data, must inevitably be processed even when
      hosting static websites does not lead to the assumption of order
      processing. This would not be appropriate. Rather, the (short-term)
      storage of IP addresses is still part of the website hoster's
      telecommunications access provision in accordance with the TKG and
      primarily serves the hoster's security purposes."</p> <p>(<a href="https://www.lda.bayern.de/media/veroeffentlichungen/FAQ_Hosting_keine_Auftragsverarbeitung.pdf" target="_blank">PDF: FAQ Hosting no order processing)</a> We assume that this exception applies to GitHub Pages.</p> <h2>3. General notes and mandatory information</h2> <h3>Data protection</h3> <p>The operators of these pages take the protection of your personal data
      very seriously. We treat your personal data confidentially and in
      accordance with the statutory data protection regulations and this privacy
      policy.</p> <p>When you use this website, various personal data is collected. Personal
      data is data that can be used to identify you personally. This privacy
      policy explains what data we collect and what we use it for. It also
      explains how and for what purpose this is done.</p> <p>We would like to point out that data transmission over the Internet (e.g.
      when communicating by email) may be subject to security vulnerabilities.
      Complete protection of data against access by third parties is not
      possible.</p> <h3>Note on the responsible body</h3> <p>The controller responsible for data processing on this website is:</p> <p>Robin Danzinger, Martin Farkas<br/>Karlstr. 120<br/>76137 Karlsruhe</p> <p>E-mail: hello@gardenjs.org</p> <p>The controller is the natural or legal person who alone or jointly with
      others determines the purposes and means of the processing of personal
      data (e.g. names, email addresses, etc.).</p> <h3>Storage duration</h3> <p>Unless a more specific storage period has been specified in this privacy
      policy, your personal data will remain with us until the purpose for data
      processing no longer applies. If you assert a justified request for
      deletion or revoke your consent to data processing, your data will be
      deleted unless we have other legally permissible reasons for storing your
      personal data (e.g. retention periods under tax or commercial law); in the
      latter case, the deletion will take place after these reasons no longer
      apply.</p> <h3>Revocation of your consent to data processing</h3> <p>Many data processing operations are only possible with your express
      consent. You can withdraw your consent at any time. The legality of the
      data processing carried out until the revocation remains unaffected by the
      revocation.</p> <h3>Right to object to the collection of data in special cases and to direct
      marketing (Art. 21 GDPR)</h3> <p>IF THE DATA PROCESSING IS BASED ON ART. 6 ABS. 1 LIT. E OR F GDPR, YOU
      HAVE THE RIGHT TO OBJECT TO THE PROCESSING OF YOUR PERSONAL DATA AT ANY
      TIME ON GROUNDS RELATING TO YOUR PARTICULAR SITUATION; THIS ALSO APPLIES
      TO PROFILING BASED ON THESE PROVISIONS. THE RESPECTIVE LEGAL BASIS ON
      WHICH PROCESSING IS BASED CAN BE FOUND IN THIS PRIVACY POLICY. IF YOU
      OBJECT, WE WILL NO LONGER PROCESS YOUR PERSONAL DATA CONCERNED UNLESS WE
      CAN DEMONSTRATE COMPELLING LEGITIMATE GROUNDS FOR THE PROCESSING WHICH
      OVERRIDE YOUR INTERESTS, RIGHTS AND FREEDOMS OR THE PROCESSING SERVES THE
      ESTABLISHMENT, EXERCISE OR DEFENSE OF LEGAL CLAIMS (OBJECTION PURSUANT TO
      ART. 21 PARA. 1 GDPR).</p> <p>IF YOUR PERSONAL DATA ARE PROCESSED FOR THE PURPOSE OF DIRECT MARKETING,
      YOU HAVE THE RIGHT TO OBJECT AT ANY TIME TO THE PROCESSING OF PERSONAL
      DATA CONCERNING YOU FOR THE PURPOSE OF SUCH MARKETING; THIS ALSO APPLIES
      TO PROFILING TO THE EXTENT THAT IT IS RELATED TO SUCH DIRECT MARKETING. IF
      YOU OBJECT, YOUR PERSONAL DATA WILL SUBSEQUENTLY NO LONGER BE USED FOR THE
      PURPOSE OF DIRECT MARKETING (OBJECTION PURSUANT TO ART. 21 PARA. 2 GDPR).</p> <h3>Right to lodge a complaint with the competent supervisory authority</h3> <p>In the event of breaches of the GDPR, data subjects have the right to
      lodge a complaint with a supervisory authority, in particular in the
      Member State of their habitual residence, place of work or place of the
      alleged infringement. The right to lodge a complaint is without prejudice
      to other administrative or judicial remedies.</p> <h3>Right to data portability</h3> <p>You have the right to have data that we process automatically on the basis
      of your consent or in fulfillment of a contract handed over to you or to a
      third party in a common, machine-readable format. If you request the
      direct transfer of the data to another controller, this will only be done
      insofar as it is technically feasible.</p> <h3>SSL or TLS encryption</h3> <p>This site uses SSL or TLS encryption for security reasons and to protect
      the transmission of confidential content, such as orders or inquiries that
      you send to us as the site operator. You can recognize an encrypted
      connection by the fact that the address line of the browser changes from
      “http://” to “https://” and by the lock symbol in your browser line.</p> <p>If SSL or TLS encryption is activated, the data you transmit to us cannot
      be read by third parties.</p> <h3>Information, deletion and correction</h3> <p>Within the framework of the applicable legal provisions, you have the
      right to free information about your stored personal data, its origin and
      recipients and the purpose of the data processing and, if necessary, a
      right to correction or deletion of this data at any time. You can contact
      us at any time if you have further questions on the subject of personal
      data.</p> <h3>Right to restriction of processing</h3> <p>You have the right to request the restriction of the processing of your
      personal data. You can contact us at any time to do this. The right to
      restriction of processing exists in the following cases:</p> <ul><li>If you dispute the accuracy of your personal data stored by us, we
        generally need time to check this. You have the right to request the
        restriction of the processing of your personal data for the duration of
        the review.</li> <li>If the processing of your personal data was/is carried out unlawfully,
        you can request the restriction of data processing instead of erasure.</li> <li>If we no longer need your personal data, but you need it for the
        exercise, defense or assertion of legal claims, you have the right to
        request the restriction of the processing of your personal data instead
        of deletion.</li> <li>If you have lodged an objection pursuant to Art. 21 (1) GDPR, a balance
        must be struck between your interests and ours. As long as it has not
        yet been determined whose interests prevail, you have the right to
        request the restriction of the processing of your personal data.</li></ul> <p>If you have restricted the processing of your personal data, this data -
      apart from its storage - may only be processed with your consent or for
      the establishment, exercise or defense of legal claims or for the
      protection of the rights of another natural or legal person or for reasons
      of important public interest of the European Union or of a Member State.</p> <h3>Objection to advertising e-mails</h3> <p>We hereby object to the use of contact data published as part of our
      obligation to provide a legal notice for the purpose of sending
      unsolicited advertising and information material. The operators of this
      website expressly reserve the right to take legal action in the event of
      the unsolicited sending of advertising information, such as spam e-mails.</p> <h2>4. Data collection on this website Server log files</h2> <p>The provider of the pages automatically collects and stores information in
      so-called server log files, which your browser automatically transmits to
      us. These are:</p> <ul><li>Browser type and browser version</li> <li>Operating system used</li> <li>Referrer URL</li> <li>Host name of the accessing computer</li> <li>Time of the server request</li> <li>IP address</li></ul> <p>This data is not merged with other data sources.</p> <p>This data is collected on the basis of Art. 6 para. 1 lit. f GDPR. The
      website operator has a legitimate interest in the technically error-free
      presentation and optimization of its website - the server log files must
      be recorded for this purpose.</p> <h3>Request by e-mail, telephone or fax</h3> <p>If you contact us by e-mail, telephone or fax, we will store and process
      your inquiry, including all personal data (name, inquiry), for the purpose
      of processing your request. We will not pass on this data without your
      consent.</p> <p>This data is processed on the basis of Art. 6 para. 1 lit. b GDPR if your
      request is related to the fulfillment of a contract or is necessary for
      the implementation of pre-contractual measures. In all other cases, the
      processing is based on our legitimate interest in the effective processing
      of the inquiries addressed to us (Art. 6 para. 1 lit. f GDPR) or on your
      consent (Art. 6 para. 1 lit. a GDPR) if this has been requested.</p> <p>The data you send to us via contact requests will remain with us until you
      ask us to delete it, revoke your consent to storage or the purpose for
      data storage no longer applies (e.g. after your request has been
      processed). Mandatory statutory provisions - in particular statutory
      retention periods - remain unaffected.</p> <p>&nbsp;</p> <p>Source: <a href="https://www.e-recht24.de" target="_blank" rel="noreferrer">eRecht24</a>. GitHub Pages: <a href="https://opr.vc/docs/hosting/github_pages/" target="_blank">GitHub</a>. Translation: <a href="https://www.deepl.com/" target="_blank">DeepL</a>.</p></div>`);function g(t){n("1ssiov5",e=>{i(()=>{s.title="Privacy Policy :: Gardenjs UI Component Explorer"})}),h(t,{children:(e,p)=>{var o=l();r(e,o)},$$slots:{default:!0}})}export{g as component};
